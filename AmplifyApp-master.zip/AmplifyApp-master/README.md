# AmplifyAppAWS
Amplify Console CI/CD
Deploy the Amplify AppReact
